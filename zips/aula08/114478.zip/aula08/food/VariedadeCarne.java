package aula08.food;

public enum VariedadeCarne {
    VACA,
    PORCO,
    PERU,
    FRANGO,
    OUTRA
}
