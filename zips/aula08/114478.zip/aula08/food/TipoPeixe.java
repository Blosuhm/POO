package aula08.food;

public enum TipoPeixe {
    CONGELADO,
    FRESCO
}
