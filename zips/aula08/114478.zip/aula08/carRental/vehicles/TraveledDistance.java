package aula08.carRental.vehicles;

public interface TraveledDistance {
    void trajectory(int kilometers);

    int lastTrajectory();

    int totalDistance();
}
