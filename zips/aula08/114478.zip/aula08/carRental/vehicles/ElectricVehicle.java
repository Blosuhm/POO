package aula08.carRental.vehicles;

public interface ElectricVehicle {

    int range();

    void recharge(int percentage);
}
