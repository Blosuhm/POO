package aula08.carRental.vehicles;

public enum MotorcycleType {
    Sport,
    Road
}
